package com.test.codingtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodingTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
