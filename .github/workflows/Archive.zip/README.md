## Spring Boot Coding Test

You are implementing a spring boot java microservice used to output an information for equity holders. 
Your microservice depends on another service which provide the relevant information. The task is to implement the 
integration with the external service and serve two apis to the user. 

### Description

You are working on the part of a bigger system which is used to manage investments. In particular,
you are working on the portfolio service which provides a portfolio summary for the user 
and a stock holding information for a particular user.


![System](docs/system.png)

Front-end requires two apis:

1. The Portfolio Summary API provides an endpoint to retrieve a summary of a user's stock portfolio.
The summary includes the total open value, total market value, total gain, and total gain percentage of all holdings.
Total open value is the sum of all stock holdings for a given user based on the average price of the holdings.
Average price is the price the user paid for the stock. 
Total market value is the sum of all holdings based on the market price for a given stock.

2. The Holding API provides an endpoint to retrieve information about a specific stock holding for a particular user.
The information includes the quantity of the stock, its ticker symbol, the average price at which it was purchased, and its current market price.

We are using openapi standard for api specifications.

Openapi specification for the above apis: [Portfolio Service APIs](docs/openapi/portfolio.yaml)


Your microservice depends on another REST service to get a list of holdings for a specific user. 

Open api specification for this service: [Holdings Service APIs](docs/openapi/dependencies/holdings.yaml)

### Task

Your task is to implement two apis which meet the [specifications](docs/openapi/portfolio.yaml).
Implementation should contain necessary tests and validations. If there are some assumptions done about handling of 
the error scenarios, please document them.


### Running dependency server

In order to test integration, please run the server which complies to test specification and returns the data
according to dependency contracts. To run the server you can start the standalone jar by running the following command

```shell
cd server
java -jar wiremock-standalone-3.9.2.jar
```
The following userIds are implemented in the server and available for testing:

1. john
2. alice
3. bob

Example calls to the external service:

```shell
curl -X GET http://localhost:8080/v1/holdings/bob
curl -X GET http://localhost:8080/v1/holdings/alice
curl -X GET http://localhost:8080/v1/holdings/john
```

### Example

For user Jack:

Holdings (retrieved from holdings service GET <HOLDINGS_SERVICE_URL>/v1/holdings/jack ) 

1. 10 shares of AAPL with average price 100$ and current market price 120.3$
2. 5 shares of MSFT with average price of 80$ and current market price 76.3$

```json
[
  {
    "quantity": 10,
    "ticker": "AAPL",
    "averagePrice": 100.0,
    "currentMarketPrice": 120.3
  },
  {
    "quantity": 5,
    "ticker": "MSFT",
    "averagePrice": 80.0,
    "currentMarketPrice": 76.3
  }
]
```


Example responses from Portfolio Service:

Summary (GET <PORTFOLIO_SERVICE_URL>/v1/summary/jack) 

```json
{
  "totalOpenValue": 1400.0,
  "totalMarketValue": 1584.5,
  "totalGain": 184.5,
  "totalGainPercentage": 13.18
}
```

Holding for MSFT (GET <PORTFOLIO_SERVICE_URL>/v1/holding/jack/MSFT)

```json
{
  "quantity": 5,
  "ticker": "MSFT",
  "averagePrice": 80.0,
  "currentMarketPrice": 76.3
}
```









